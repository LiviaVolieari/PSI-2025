## Estrutura do banco

banco
1 : {nome:senha}